<div>
    <x-jet-secondary-button class="ml-12" wire:loading.attr="disabled" wire:target="" wire:click="">
        <i class="fas fa-heart text-red-500 text-lg"></i>
    </x-jet-secondary-button>
</div>

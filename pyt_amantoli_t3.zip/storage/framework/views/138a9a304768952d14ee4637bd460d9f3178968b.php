<div wire:init="loadPosts">
    <?php if(count($products)): ?>
        <div class="glider-contain">
            <ul class="glider-<?php echo e($category->id); ?>">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="bg-white rounded-lg shadow <?php echo e($loop->last ? '' : 'sm:mr-4'); ?>">
                        <article>
                            <a href="<?php echo e(route('products.show', $product)); ?>">
                                <figure>

                                    <?php if($product->images->count()): ?>
                                        <img class="h-48 w-full object-cover object-center"
                                            src="<?php echo e(Storage::url($product->images->first()->url)); ?>"
                                            alt="img-<?php echo e($product->slug); ?>">
                                    <?php else: ?>
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.icon-product-deafult','data' => []]); ?>
<?php $component->withName('icon-product-deafult'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                </figure>
                            </a>
                            <div class="py-4 px-6">
                                <h1 class="text-lg font-semibold">
                                    <a href="<?php echo e(route('products.show', $product)); ?>">
                                        <?php echo e(Str::limit($product->name, 20)); ?>

                                    </a>
                                </h1>
                                <p class="font-bold text-trueGray-700">$MXN <?php echo e($product->price); ?></p>
                            </div>
                        </article>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <button aria-label="Previous" class="glider-prev">«</button>
            <button aria-label="Next" class="glider-next">»</button>
            <div role="tablist" class="dots"></div>
        </div>
    <?php else: ?>
        <div class="mb-4 h-48 flex justify-center items-center bg-white shadow-xl border border-gray-100 rounded-lg">
            <i class="fas fa-spinner animate-spin text-Orange-700 sm:text-5xl text-3xl"></i>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\pyt_amantoli_t3\resources\views/livewire/category-products.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-12">

        <section class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 text-white">
            <a href="<?php echo e(route('admin.orders.index') . '?status=2'); ?>"
                class="bg-blue-500 shadow-lg bg-opacity-85 rounded-lg px-12 pt-8 pb-4">
                <p class="text-center text-2xl">
                    <?php echo e($pagado); ?>

                </p>
                <p class="uppercase text-center">Pagado</p>
                <p class="text-center text-2xl mt-2">
                    <i class="fas fa-credit-card"></i>
                </p>
            </a>
            <a href="<?php echo e(route('admin.orders.index') . '?status=3'); ?>"
                class="bg-pink-500 shadow-lg bg-opacity-85 rounded-lg px-12 pt-8 pb-4">
                <p class="text-center text-2xl">
                    <?php echo e($enviado); ?>

                </p>
                <p class="uppercase text-center">Enviado</p>
                <p class="text-center text-2xl mt-2">
                    <i class="fas fa-truck"></i>
                </p>
            </a>
            <a href="<?php echo e(route('admin.orders.index') . '?status=4'); ?>"
                class="bg-green-500 shadow-lg bg-opacity-85 rounded-lg px-12 pt-8 pb-4">
                <p class="text-center text-2xl">
                    <?php echo e($entregado); ?>

                </p>
                <p class="uppercase text-center">Entregado</p>
                <p class="text-center text-2xl mt-2">
                    <i class="fas fa-check-circle"></i>
                </p>
            </a>
            <a href="<?php echo e(route('admin.orders.index') . '?status=5'); ?>"
                class="bg-red-500 shadow-lg bg-opacity-85 rounded-lg px-12 pt-8 pb-4">
                <p class="text-center text-2xl">
                    <?php echo e($anulado); ?>

                </p>
                <p class="uppercase text-center">Anulado</p>
                <p class="text-center text-2xl mt-2">
                    <i class="fas fa-times-circle"></i>
                </p>
            </a>
        </section>

        <?php if($orders->count()): ?>
            <section class="bg-white shadow-lg rounded-lg px-12 py-8 mt-12 text-gray-700">
                <h1 class="text-2xl mb-4">Pedidos recientes</h1>
                <ul>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="">
                            <a href="<?php echo e(route('admin.orders.show', $order)); ?>"
                                class="flex items-center py-2 px-4 hover:bg-gray-100">
                                <span>
                                    <?php switch($order->status):

                                        case (2): ?>
                                            <i class="fas fa-credit-card text-blue-500 opacity-50">

                                            </i>
                                        <?php break; ?>
                                        <?php case (3): ?>
                                            <i class="fas fa-truck text-pink-500 opacity-50">

                                            </i>
                                        <?php break; ?>
                                        <?php case (4): ?>
                                            <i class="fas fa-check-circle text-green-500 opacity-50">

                                            </i>
                                        <?php break; ?>
                                        <?php case (5): ?>
                                            <i class="fas fa-times-circle text-red-500 opacity-50">

                                            </i>
                                        <?php break; ?>
                                        <?php default: ?>

                                    <?php endswitch; ?>
                                </span>
                                <span>
                                    Orden: <?php echo e($order->id); ?>

                                    <br>
                                    <?php echo e($order->created_at->format('d/m/Y')); ?>

                                </span>
                                <div class="ml-auto">
                                    <span class="font-bold">
                                        <?php switch($order->status):
                                            case (1): ?>
                                                Pendiente
                                            <?php break; ?>
                                            <?php case (2): ?>
                                                Pagado
                                            <?php break; ?>
                                            <?php case (3): ?>
                                                Enviado
                                            <?php break; ?>
                                            <?php case (4): ?>
                                                Entregado
                                            <?php break; ?>
                                            <?php case (5): ?>
                                                Anulado
                                            <?php break; ?>
                                            <?php default: ?>

                                        <?php endswitch; ?>
                                    </span>
                                    <br>
                                    <span class="text-sm">
                                        $<?php echo e($order->total); ?> MXN
                                    </span>
                                </div>
                                <span>
                                    <i class="fas fa-angle-right ml-6"></i>
                                </span>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </section>
        <?php else: ?>
            <div class="bg-white shadow-lg rounded-lg px-12 py-8 mt-12 text-gray-700">
                <div class="bg-blue-100 border-t border-b border-blue-500 text-blue-700 px-4 py-3" role="alert">
                    <p class="font-bold">No se ha encontrado ningún registro</p>
                    <p class="text-sm">Actualmente no hay ninguna orden para mostrar</p>
                </div>
            </div>
        <?php endif; ?>
    </div>

 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pyt_amantoli_t3\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>
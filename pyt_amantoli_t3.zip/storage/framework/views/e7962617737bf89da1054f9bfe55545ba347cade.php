<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-8">
        <nav class="p-3 rounded font-sans w-full" aria-label="breadcrumb">
            <ol class="flex leading-none text-indigo-600 divide-x divide-indigo-400">
                <li class="pr-4"><a href="#">Inicio</a></li>
                <li class="px-4 text-gray-700" aria-current="page"><?php echo e($product->name); ?></li>
            </ol>
        </nav>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            

            <div>
                <div class="flexslider">
                    <ul class="slides">
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->images->count()): ?>
                                <li data-thumb="<?php echo e(Storage::url($image->url)); ?>">
                                    <img src="<?php echo e(Storage::url($image->url)); ?>" />
                                </li>
                            <?php else: ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.icon-product-deafult','data' => []]); ?>
<?php $component->withName('icon-product-deafult'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="-mt-10 text-gray-700">
                    <h2 class="font-bold text-lg">Descripción</h2>
                    <?php echo $product->description; ?>

                </div>
            </div>
            
            <div>
                <h1 class="text-xl font-bold text-trueGray-700"><?php echo e($product->name); ?></h1>
                <div class="flex">
                    <p class="text-trueGray-700">Marca: <a class="underline capitalize hover:text-Orange-500"
                            href=""><?php echo e($product->brand->name); ?></a>
                    </p>
                    <p class="text-trueGray-700 mx-6">5 <i class="fas fa-star text-sm text-yellow-400"></i></p>
                    <a class="text-Orange-500 hover:text-Orange-600 underline" href="">39 reseñas</a>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-favorite-item', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('Xn3bnjj')) {
    $componentId = $_instance->getRenderedChildComponentId('Xn3bnjj');
    $componentTag = $_instance->getRenderedChildComponentTagName('Xn3bnjj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Xn3bnjj');
} else {
    $response = \Livewire\Livewire::mount('add-favorite-item', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('Xn3bnjj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <p class="text-2xl font-semibold text-trueGray-700 my-4">$MXN <?php echo e($product->price); ?></p>
                <div class="bg-white rounded-lg shadow-lg mb-6">
                    <div class="p-4 flex items-center">
                        <span class="flex items-center justify-center h-10 w-10 rounded-full bg-greenLime-600">
                            <i class="fas fa-truck text-sm text-white"></i>
                        </span>
                        <div class="ml-4">
                            <p class="text-lg font-semibold text-greenLime-600">Se hacen envíos a todo México</p>
                            <p>Recibelo el <?php echo e(Date::now()->addDay(7)->locale('es')->format('l j F')); ?></p>
                        </div>
                    </div>
                </div>
                <?php if($product->subcategory->size): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-cart-item-size', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('R0kuEHf')) {
    $componentId = $_instance->getRenderedChildComponentId('R0kuEHf');
    $componentTag = $_instance->getRenderedChildComponentTagName('R0kuEHf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('R0kuEHf');
} else {
    $response = \Livewire\Livewire::mount('add-cart-item-size', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('R0kuEHf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php elseif($product->subcategory->color): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-cart-item-color', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('uvLQPE9')) {
    $componentId = $_instance->getRenderedChildComponentId('uvLQPE9');
    $componentTag = $_instance->getRenderedChildComponentTagName('uvLQPE9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uvLQPE9');
} else {
    $response = \Livewire\Livewire::mount('add-cart-item-color', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('uvLQPE9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php else: ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-cart-item', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('Lklfr5C')) {
    $componentId = $_instance->getRenderedChildComponentId('Lklfr5C');
    $componentTag = $_instance->getRenderedChildComponentTagName('Lklfr5C');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Lklfr5C');
} else {
    $response = \Livewire\Livewire::mount('add-cart-item', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('Lklfr5C', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php $__env->startPush('script'); ?>
        <script>
            $(document).ready(function() {
                $('.flexslider').flexslider({
                    animation: "slide",
                    controlNav: "thumbnails"
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pyt_amantoli_t3\resources\views/products/show.blade.php ENDPATH**/ ?>
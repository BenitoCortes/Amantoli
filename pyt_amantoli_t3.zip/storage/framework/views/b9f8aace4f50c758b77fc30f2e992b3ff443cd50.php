<div x-data>
    <p class="text-xl text-gray-700">Color:</p>
    <select wire:model="color_id" class="form-control w-full">
        <option value="" selected disabled>Seleccionar un color</option>
        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option class="capitalize" value="<?php echo e($color->id); ?>"><?php echo e(__($color->name)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <p class="text-gray-700 my-4"><span class="font-semibold text-lg">Stock disponible:</span>
        <?php if($quantity): ?>
            <?php echo e($quantity); ?>

        <?php else: ?>
            <?php echo e($product->stock); ?>

        <?php endif; ?>
    </p>

    <div class="flex">
        <div class="mr-4">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['disabled' => true,'xBind:disabled' => '$wire.qty <= 1','wire:loading.attr' => 'disabled','wire:target' => 'decrement','wire:click' => 'decrement']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['disabled' => true,'x-bind:disabled' => '$wire.qty <= 1','wire:loading.attr' => 'disabled','wire:target' => 'decrement','wire:click' => 'decrement']); ?>
                -
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <span class="mx-2 text-gray-700"><?php echo e($qty); ?></span>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['xBind:disabled' => '$wire.qty >= $wire.quantity','wire:loading.attr' => 'disabled','wire:target' => 'increment','wire:click' => 'increment']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-bind:disabled' => '$wire.qty >= $wire.quantity','wire:loading.attr' => 'disabled','wire:target' => 'increment','wire:click' => 'increment']); ?>
                +
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <div class="flex-1">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['xBind:disabled' => '!$wire.quantity','color' => 'Orange','class' => 'w-full','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-bind:disabled' => '!$wire.quantity','color' => 'Orange','class' => 'w-full','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem']); ?>
                <i class="fas fa-spinner animate-spin text-white text-lg" wire:loading wire:target="addItem"></i>
                Agregar al carrito de compras
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\pyt_amantoli_t3\resources\views/livewire/add-cart-item-color.blade.php ENDPATH**/ ?>
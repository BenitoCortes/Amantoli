<svg class="h-10 w-10 rounded-full object-cover" version="1.1" viewBox="0 0 800.00001 800.00001"
    xmlns="http://www.w3.org/2000/svg">
    <defs>
        <linearGradient id="c" x1="338.63" x2="-108.12" y1="488.12" y2="884.73" gradientUnits="userSpaceOnUse">
            <stop offset="0" />
            <stop stop-opacity="0" offset="1" />
        </linearGradient>
        <mask id="b" maskUnits="userSpaceOnUse">
            <circle cx="400" cy="400" r="400" color="#000000" color-rendering="auto" fill="#fff" image-rendering="auto"
                shape-rendering="auto" solid-color="#000000" style="isolation:auto;mix-blend-mode:normal" />
        </mask>
        <mask id="a" maskUnits="userSpaceOnUse">
            <circle cx="400" cy="400" r="400" color="#000000" color-rendering="auto" fill="#fff" image-rendering="auto"
                shape-rendering="auto" solid-color="#000000" style="isolation:auto;mix-blend-mode:normal" />
        </mask>
    </defs>
    <circle cx="400" cy="400" r="400" color="#000000" color-rendering="auto" fill="#1c8adb" image-rendering="auto"
        shape-rendering="auto" solid-color="#000000" style="isolation:auto;mix-blend-mode:normal" />
    <path d="m177.61 225.72-177.61 177.61c-2.492 296.28 153.19 392.91 393.28 396.64l229.1-229.1v-345.15z"
        color="#000000" color-rendering="auto" fill="url(#c)" image-rendering="auto" mask="url(#a)" opacity=".42"
        shape-rendering="auto" solid-color="#000000" style="isolation:auto;mix-blend-mode:normal" />
    <path
        d="m177.61 225.72v345.15h444.78v-345.15h-444.78zm44.426 45.661h355.92v253.82h-355.92v-253.82zm87.226 31.728a33.803 33.803 0 0 0 -33.804 33.804 33.803 33.803 0 0 0 33.804 33.802 33.803 33.803 0 0 0 33.804 -33.802 33.803 33.803 0 0 0 -33.804 -33.804zm134.92 37.657-53.966 76.502-29.058-28.169-84.508 88.363h259.75l-92.218-136.7z"
        color="#000000" color-rendering="auto" fill="#fff" image-rendering="auto" mask="url(#b)" shape-rendering="auto"
        solid-color="#000000" style="isolation:auto;mix-blend-mode:normal" />
</svg>
<?php /**PATH C:\xampp\htdocs\pyt_amantoli_t3\resources\views/components/icon-product-deafult.blade.php ENDPATH**/ ?>